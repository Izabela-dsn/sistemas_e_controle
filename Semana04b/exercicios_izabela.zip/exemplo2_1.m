% exemplo 2.1 - resolvendo função de transferencia

numerador = [2 5 3 6]
denominador = [1 6 11 6]
[r,p,k] = residue(numerador, denominador)

% (-6/s+3) + (-4/s+2) + (3/s+1) + 2