%exemplo 2.7 - resolver a equação diferencial 
num = [2]
den = [1 2 10 0 0 0]

%fração parcial
[r,p,k] = residue(num, den)

